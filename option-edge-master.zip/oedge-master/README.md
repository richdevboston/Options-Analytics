oedge
=====

A user can enter positions in any configuration and then visualize profitability scenarios in a data grid and chart. Slider and spinner controls allow changing of parameters to see how it affects strategy outcome.

![Screenshot](https://github.com/edgek/oedge/blob/master/screenshot.jpg)
